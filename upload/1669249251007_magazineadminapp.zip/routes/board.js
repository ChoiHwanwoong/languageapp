var express = require('express');
var router = express.Router();
var path = require('path');

//날짜포맷 지원 moment팩키지 참조 
var moment = require('moment');

//ORM DB객체 참조 
var db = require('../models/index');


/* GET home page. */
router.get('/list', async(req, res, next) => {

    //step1:DB에서 게시글 목록 데이터를 조회해옵니다.
    var boardList = await db.Article.findAll();
    res.render('boards/list.ejs',{boardList,moment});

    

  });
  
//게시글 등록 웹페이지 반환-GET
//http://localhost:3000/boards/create
router.get('/create',async(req,res)=>{
    res.render('boards/create');
});


//게시글 등록- 게시글 등록 데이터 처리-POST
//http://localhost:3000/boards/create
//호출주소가 같더라도 호출방식이 다르면 개별적으로 호출가능
router.post('/create',async(req,res)=>{

    //step1: 웹브라우저에서 form태그내 전달되는 데이터 추출
    var title = req.body.title; //사용자가 입력한 게시글 제목값을 추출
    var contents =req.body.contents;

    console.log("사용자가 입력한 게시글 제목:",title);

    //step2:추출된 사용자 입력값을 DB에 저장합니다.
    var articleData ={
        board_idx:1,
        title,
        contents,
        view_cnt:0,
        ip_address:req.ip,
        display_yn:'Y',
        regist_date:Date.now(),
        regist_userid:"CHW"
    };

    //step3:orm model를 이용해 데이터를 등록처리한다.
    var registArticleData = await db.Article.create(articleData);

    //step3: 특정 화면(뷰)를 전달하거나 또는 특정 페이지로 이동시킵니다.
    //게시글 목록 페이지(URL주소)로 이동시킵니다.
    res.redirect('/boards/list');
});


//게시글 수정 데이터 처리 -PUT-사용자 입력한 데이터를 기반으로 DB데이터를 수정하고 목록페이지로 이동
//http://localhost:3000/boards/modify
router.post('/modify',async(req,res)=>{

    //step1:사용자가 form태그내에서 입려한 수정데이터를 추출
    const articleIdx = req.body.articleIdx; //히든필드의 게시글 고유번호 받아오기
    const title = req.body.title;
    const contents = req.body.contents;

    console.log("사용자가 수정한 게시글제목 데이터: ",title);

    //step2:수정할 데이터 준비 및 DB에 데이터 수정처리
    var updateArticle = {
        title,
        contents,
        modify_date:Date.now(),
    }

    var updatedCnt = await db.Article.update(updateArticle,{where:{article_idx:articleIdx}});


    //step3:데이터 수정이 완료되면 게시글 목록 페이지로 이동처리
    res.redirect('/boards/list');

});


//게시글 삭제 요청 처리하기 
//http://localhost:3000/boards/delete?idx=1
router.get('/delete',async(req,res)=>{

    //step1:삭제하고자 하는 게시글 고유번호를 추출합니다.
    const articleIdx = req.query.idx;
    console.log("삭제하고자 하는 게시글 번호:",articleIdx);

    //step2:해당 게시글 번호 기준으로 해당 게시글 DB에서 삭제처리하기
    var deletedCnt = await db.Article.destroy({where:{article_idx:articleIdx}});

    //step3:해당 게시글이 삭제가 완료되면 게시글 목록 페이지로 이동하기
    res.redirect('/boards/list');


 
});




//게시글 수정 웹페이지 호출-Get-Parameter방식으로 값이 전달되는경우
//http://localhost:3000/articles/update/2
//주의점: 중요 되도록 와이일드 카드방식을 호출하는 라우팅 메소드는  라우팅파일내 최 하단으로 배치 시켜줍니다.
router.get('/modify/:idx',async(req,res)=>{

    //step1: 파라메터로 전달되는 값을 추출하기
    //URL파라메터 로 전달되는 값은 와일드카드에서 지정한 키값으로 req.params.키값 으로 추출이 가능합니다.
    const articleIdx = req.params.idx;

    //step2-1: 해당 게시글 고유번호에 해당하는 단일게시글 정보를 DB에서 조회해옵니다.
    var article = await db.Article.findOne({where:{article_idx:articleIdx}});

    //step2-2: 단일게시글 조회수 증가 수정처리 
    var updateArticle ={
        view_cnt:article.view_cnt +1,
        modify_date:Date.now(),
    }

    //조회수 DB 수정 처리 
    await db.Article.update(updateArticle,{where:{article_idx:articleIdx}});

    //조회 게시글의 조회수 갱신
    article.view_cnt +=1;

    res.render('boards/modify',{article});
});




  module.exports = router;
  